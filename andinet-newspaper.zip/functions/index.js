// functions/index.js - Add this at the top with other requires
const Stripe = require('stripe');

// Initialize Stripe safely
const getStripe = () => {
  try {
    const stripeSecret = functions.config().stripe?.secret_key;
    if (!stripeSecret) {
      console.warn('⚠️ No Stripe secret key found, using mock mode');
      return null;
    }
    return new Stripe(stripeSecret, {
      apiVersion: '2023-10-16',
    });
  } catch (error) {
    console.error('Error initializing Stripe:', error);
    return null;
  }
};

// Create payment intent
exports.createPaymentIntent = functions.https.onCall(async (data, context) => {
  const { amount, currency = 'usd' } = data;
  
  if (!amount || amount < 1) {
    throw new functions.https.HttpsError('invalid-argument', 'Invalid amount');
  }
  
  try {
    const stripe = getStripe();
    
    // For emulator/testing, return mock data
    if (!stripe || process.env.FUNCTIONS_EMULATOR === 'true') {
      console.log('🔧 Emulator mode: Creating mock payment intent for $' + amount);
      return {
        clientSecret: 'mock_secret_' + Date.now(),
        paymentIntentId: 'mock_pi_' + Date.now(),
        mock: true
      };
    }
    
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // Stripe uses cents
      currency: currency,
      metadata: {
        userId: context.auth?.uid || 'anonymous',
        userEmail: context.auth?.token?.email || 'anonymous'
      }
    });
    
    return {
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id
    };
  } catch (error) {
    console.error('Error creating payment intent:', error);
    throw new functions.https.HttpsError('internal', 'Unable to process payment');
  }
});

// Webhook for Stripe events (for production)
exports.stripeWebhook = functions.https.onRequest(async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = functions.config().stripe?.webhook_secret;
  
  if (!webhookSecret) {
    console.warn('No webhook secret configured');
    res.status(400).send('Webhook secret not configured');
    return;
  }
  
  let event;
  
  try {
    const stripe = getStripe();
    event = stripe.webhooks.constructEvent(req.rawBody, sig, webhookSecret);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    res.status(400).send(`Webhook Error: ${err.message}`);
    return;
  }
  
  // Handle the event
  switch (event.type) {
    case 'payment_intent.succeeded':
      const paymentIntent = event.data.object;
      console.log('Payment succeeded:', paymentIntent.id);
      
      // Save successful donation to Firestore
      await admin.firestore().collection('donations').add({
        amount: paymentIntent.amount / 100,
        currency: paymentIntent.currency,
        stripePaymentId: paymentIntent.id,
        userId: paymentIntent.metadata.userId,
        userEmail: paymentIntent.metadata.userEmail,
        status: 'completed',
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
      break;
      
    case 'payment_intent.payment_failed':
      console.log('Payment failed:', event.data.object.id);
      break;
      
    default:
      console.log(`Unhandled event type ${event.type}`);
  }
  
  res.json({ received: true });
});

// functions/index.js
const functions = require('firebase-functions');
const admin = require('firebase-admin');
const nodemailer = require('nodemailer');

admin.initializeApp();

// SAFE config access - handles undefined gracefully
const getEmailConfig = () => {
  try {
    // For emulator, always use mock mode
    if (process.env.FUNCTIONS_EMULATOR === 'true' || process.env.FIREBASE_EMULATOR_HUB) {
      console.log('🔧 Emulator mode detected - using mock email');
      return {
        user: null,
        pass: null,
        admin: 'admin@emulator.com',
        isMock: true
      };
    }
    
    // For production, try to get config
    const config = functions.config();
    if (!config || !config.email) {
      console.warn('⚠️ No email config found, using mock mode');
      return {
        user: null,
        pass: null,
        admin: 'admin@example.com',
        isMock: true
      };
    }
    
    return {
      user: config.email.user || null,
      pass: config.email.pass || null,
      admin: config.email.admin || 'admin@example.com',
      isMock: false
    };
  } catch (error) {
    console.error('Error getting email config:', error);
    return {
      user: null,
      pass: null,
      admin: 'admin@example.com',
      isMock: true
    };
  }
};

// Create mock transporter for development
const createMockTransporter = () => {
  return {
    sendMail: async (options) => {
      console.log('\n📧 ========== MOCK EMAIL ==========');
      console.log('   To:', options.to);
      console.log('   Subject:', options.subject);
      console.log('   Body preview:', options.html?.substring(0, 300) + '...');
      console.log('   ================================\n');
      return { messageId: 'mock-' + Date.now() };
    }
  };
};

// Create real transporter
const createRealTransporter = (config) => {
  if (!config.user || !config.pass) {
    console.warn('⚠️ Invalid email credentials, using mock');
    return createMockTransporter();
  }
  
  try {
    return nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: config.user,
        pass: config.pass
      }
    });
  } catch (error) {
    console.error('Error creating transporter:', error);
    return createMockTransporter();
  }
};

// Get transporter based on environment
let transporter = null;
const getTransporter = () => {
  if (transporter) return transporter;
  
  const config = getEmailConfig();
  
  if (config.isMock || !config.user) {
    transporter = createMockTransporter();
  } else {
    transporter = createRealTransporter(config);
  }
  
  return transporter;
};

// ============= FUNCTIONS =============

// Welcome email on user signup
exports.sendWelcomeEmail = functions.auth.user().onCreate(async (user) => {
  console.log(`🆕 New user created: ${user.email}`);
  
  const mailOptions = {
    from: '"The Andinet Gazette" <noreply@andinet-gazette.com>',
    to: user.email,
    subject: 'Welcome to The Andinet Gazette',
    html: `
      <div style="font-family: Georgia, serif; max-width: 600px; margin: 0 auto;">
        <h1 style="font-size: 28px; border-bottom: 2px solid #000;">Welcome to The Andinet Gazette</h1>
        <p>Dear ${user.displayName || 'Reader'},</p>
        <p>Thank you for joining The Andinet Gazette community.</p>
        <p>With your account, you can:</p>
        <ul>
          <li>Comment on articles and join discussions</li>
          <li>Support our work through donations</li>
          <li>Receive our newsletter</li>
        </ul>
        <p>Start exploring: <a href="http://localhost:5173">The Andinet Gazette</a></p>
        <hr>
        <p style="color: #666; font-size: 12px;">The Andinet Gazette - Independent journalism</p>
      </div>
    `
  };

  try {
    const transporter = getTransporter();
    await transporter.sendMail(mailOptions);
    console.log(`✅ Welcome email sent to ${user.email}`);
  } catch (error) {
    console.error('❌ Error sending welcome email:', error);
  }
});

// Password reset function
exports.sendPasswordResetEmail = functions.https.onCall(async (data, context) => {
  console.log('📧 Password reset requested for:', data.email);
  
  // For emulator, just return success
  const config = getEmailConfig();
  if (config.isMock) {
    console.log('🔧 Emulator mode: Password reset would be sent to:', data.email);
    return { success: true, mock: true };
  }
  
  const { email } = data;
  if (!email) {
    throw new functions.https.HttpsError('invalid-argument', 'Email is required');
  }
  
  try {
    const link = await admin.auth().generatePasswordResetLink(email);
    
    const mailOptions = {
      from: '"The Andinet Gazette" <noreply@andinet-gazette.com>',
      to: email,
      subject: 'Reset Your Password - The Andinet Gazette',
      html: `
        <div style="font-family: Georgia, serif; max-width: 600px;">
          <h1>Reset Your Password</h1>
          <p>Click the link below to reset your password:</p>
          <p><a href="${link}">Reset Password</a></p>
          <p>This link expires in 1 hour.</p>
          <p>If you didn't request this, ignore this email.</p>
        </div>
      `
    };
    
    const transporter = getTransporter();
    await transporter.sendMail(mailOptions);
    return { success: true };
  } catch (error) {
    console.error('Error sending reset email:', error);
    throw new functions.https.HttpsError('internal', 'Unable to send reset email');
  }
});

// Contact form function
exports.sendContactEmail = functions.https.onCall(async (data, context) => {
  console.log('📧 Contact form submission from:', data.email);
  
  const { name, email, message } = data;
  
  if (!name || !email || !message) {
    throw new functions.https.HttpsError('invalid-argument', 'All fields are required');
  }
  
  try {
    // Save to Firestore
    await admin.firestore().collection('contacts').add({
      name,
      email,
      message,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      status: 'unread'
    });
    
    // For emulator, just log and return
    const config = getEmailConfig();
    if (config.isMock) {
      console.log('🔧 Emulator mode: Contact confirmation would be sent to:', email);
      return { success: true, mock: true };
    }
    
    // Send confirmation to user
    const userMailOptions = {
      from: '"The Andinet Gazette" <noreply@andinet-gazette.com>',
      to: email,
      subject: 'We Received Your Message',
      html: `
        <h3>Thank you for contacting The Andinet Gazette</h3>
        <p>Dear ${name},</p>
        <p>We have received your message and will respond within 2-3 business days.</p>
        <p>Best regards,<br>The Andinet Gazette Team</p>
      `
    };
    
    const transporter = getTransporter();
    await transporter.sendMail(userMailOptions);
    
    return { success: true };
  } catch (error) {
    console.error('Error:', error);
    throw new functions.https.HttpsError('internal', 'Failed to send message');
  }
});

// Test function
exports.ping = functions.https.onCall((data, context) => {
  console.log('🏓 Ping called');
  return { message: 'pong', timestamp: Date.now() };
});

console.log('✅ Functions loaded successfully');
